package hu.szamalk.nezet;

import hu.szamalk.modell.Jarmu;
import hu.szamalk.modell.Kolcsonzo;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class GuiForm {
    private JList list1;
    private JLabel jLabel;
    private JComboBox cmbelemek;
    private JPanel pnlMain;
    private JFrame frame;
    private  JMenuItem beolvas;
    private  JMenuItem   kilepes;

    public GuiForm(){
        ini();

        beolvas.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser jfc=new JFileChooser(new File(System.getProperty("jarmuvek.ser")));
                if(jfc.showOpenDialog(null)==JFileChooser.APPROVE_OPTION){
                    File fajl=jfc.getSelectedFile();
                    try(ObjectInputStream ois= new ObjectInputStream(new FileInputStream(fajl))){
                        Kolcsonzo modell = new Kolcsonzo();
                        DefaultComboBoxModel<String>dcbm=(DefaultComboBoxModel<String>)cmbelemek.getModel();
                        for(Jarmu s:modell.getJarmuvek()){
                            dcbm.addElement(s.toString());
                        }
                    } catch (FileNotFoundException ex) {
                        throw new RuntimeException(ex);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });
        kilepes.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                kilepes();
            };
        });

    };
    private  void kilepes() {
        String uzenet = "Kilépsz?";
        String cim = "Kilépés";
        int opt = JOptionPane.YES_NO_OPTION;
        int gomb = JOptionPane.showConfirmDialog(null, uzenet, cim, opt);
        if (gomb == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private void ini() {
        frame=new JFrame("Jarmuvek");
        frame.setContentPane(pnlMain);
        frame.setSize(520, 240);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        JMenu menu=new JMenu("Jarmuvek");
        beolvas=new JMenuItem("Beolvasás");
        menu.add(beolvas);
        menu.add(new JSeparator());
        menu.add(kilepes);
        JMenuBar menuBar=new JMenuBar();
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);
        frame.setVisible(true);
    }

    ;
}
