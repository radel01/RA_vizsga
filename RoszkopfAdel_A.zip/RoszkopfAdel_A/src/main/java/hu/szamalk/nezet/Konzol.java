package hu.szamalk.nezet;

import hu.szamalk.modell.Jarmu;
import hu.szamalk.modell.Kolcsonzo;

import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Konzol {
    Kolcsonzo kolcsonzo=new Kolcsonzo();

    public static void main(String[] args) {
        new Konzol().feladatok();
    }

    public void feladatok(){
        jarmuvekKonzolon();
        jarmuvekFajlban();
        melyikNaponMelyikAuto();
    }

    private void melyikNaponMelyikAuto() {
    }

    private void jarmuvekFajlban() {
        try(ObjectOutputStream objKI= new ObjectOutputStream(new FileOutputStream("jarmuvek.ser"))){
            for(Jarmu jarmu:kolcsonzo.getJarmuvek()){
                objKI.writeObject(jarmu);
            }
            System.out.println("A 'jarmuvek.ser' kiirva!");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void jarmuvekKonzolon() {
        System.out.println("A kölcsönző járművei:");
        for(Jarmu jarmu:kolcsonzo.getJarmuvek()){
            System.out.println("\t"+jarmu);
        }
    }
}
