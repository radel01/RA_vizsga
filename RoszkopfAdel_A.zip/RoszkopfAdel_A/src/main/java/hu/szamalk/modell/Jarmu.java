package hu.szamalk.modell;

import java.util.Collections;
import java.util.List;

public class Jarmu {
    private String rendszam;
    private Minosites minosites;

    public Jarmu(String rendszam, Minosites minosites) {
        this.minosites = minosites;
        if (!rendszam.contains("-")) {
            throw new NincsKotojelException("A renszám nem tartalmaz kötőjelet!");
        }else {
            this.rendszam = rendszam;
        }
    }

    public String getRendszam() {
        return rendszam;
    }

    public Minosites getMinosites() {
        return minosites;
    }

    public void setRendszam(String rendszam) {
        this.rendszam = rendszam;
    }

    public void setMinosites(Minosites minosites) {
        this.minosites = minosites;
    }

    @Override
    public String toString() {
        return "Jarmu{" +
                "rendszam='" + rendszam + '\'' +
                ", minosites=" + minosites +
                '}';
    }
}
