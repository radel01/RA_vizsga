package hu.szamalk.modell;

import java.io.Serializable;

public class Hajo extends Jarmu implements Serializable {
    private String nev;
    private int ferohely;

    public Hajo(String rendszam, Minosites minosites,String nev, int ferohely) {
        super(rendszam, minosites);
            this.nev = nev;
            this.ferohely = ferohely;
    }


    public String getNev() {
        return nev;
    }

    public int getFerohely() {
        return ferohely;
    }

    @Override
    public String toString() {
        return "Hajo{" +
                "nev='" + nev + '\'' +
                ", ferohely=" + ferohely +
                '}';
    }
}
