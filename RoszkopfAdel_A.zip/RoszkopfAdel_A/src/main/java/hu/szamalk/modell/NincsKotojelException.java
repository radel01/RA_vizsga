package hu.szamalk.modell;

public class NincsKotojelException extends RuntimeException{
    public NincsKotojelException(String uzenet){
        super(uzenet);
    }
}
