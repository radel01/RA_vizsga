package hu.szamalk.modell;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class Kolcsonzo {
    private List<Jarmu> jarmuvek;

    public Kolcsonzo(){
        jarmuvek= new ArrayList<>();
        jarmuvek.add(new Auto("ABC-234", Minosites.MEGFELELO, UUID.randomUUID(), "kedd"));
        jarmuvek.add(new Auto("BCA-456", Minosites.ATLAGOS, UUID.randomUUID(), "szerda"));
        jarmuvek.add(new Hajo("ABC-234", Minosites.MEGFELELO, "Hableány", 20));
    }

    public List<Jarmu>getJarmuvek(){
        return Collections.unmodifiableList(jarmuvek);
    }

    @Override
    public String toString() {
        return "Kolcsonzo{" +
                "jarmuvek=" + jarmuvek +
                '}';
    }
}
