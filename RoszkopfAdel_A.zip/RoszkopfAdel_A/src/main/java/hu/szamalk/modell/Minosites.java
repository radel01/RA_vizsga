package hu.szamalk.modell;

public enum Minosites {
    KIVALO, ATLAGOS, MEGFELELO;
}
