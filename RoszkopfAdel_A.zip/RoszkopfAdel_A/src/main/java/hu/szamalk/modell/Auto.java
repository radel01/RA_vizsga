package hu.szamalk.modell;

import java.io.Serializable;
import java.util.Collection;
import java.util.UUID;

public class Auto extends Jarmu implements Comparable<Auto>, Serializable {
    private UUID id;
    private String nap;

    public Auto(String rendszam, Minosites minosites, UUID id, String nap) {
        super(rendszam, minosites);
        this.id = UUID.randomUUID();
        this.nap = "Hétfő";
    }


    public UUID getId() {
        return id;
    }

    public String getNap() {
        return nap;
    }

    public void setNap(String nap) {
        this.nap = nap;
    }

    @Override
    public String toString() {
        return "Auto{" +
                "id=" + id +
                ", nap='" + nap + '\'' +
                '}';
    }

    @Override
    public int compareTo(Auto masik) {
        return this.getRendszam().compareTo(masik.getRendszam());
    }

}
