import { createContext, use, useCallback, useContext, useState } from "react";
import { myAxios } from "./myAxios";

const ApiContext= createContext();

export const ApiProvider=({children})=>{

    const [adat, setAdatok]=useState([]);
    const [valaszHelyes, setValaszHelyes]=useState([]);

    const getAdatok=async(vegpont)=>{
        try{
            const{data}=await myAxios.get(vegpont);
            setAdatok(data);
            console.log(data);
        }catch(error){
            console.log("Hiba mentés közben: ", error.response?.data);
        }
    }


return(
    <ApiContext.Provider value={{
        adat,
        getAdatok,
        setAdatok,
        valaszHelyes, 
        setValaszHelyes
    }}>
    {children}
    </ApiContext.Provider>
);

};
export default function useApiContext(){
    return useContext(ApiContext);
}