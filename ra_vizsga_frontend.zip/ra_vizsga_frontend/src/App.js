import logo from './logo.svg';
import './App.css';
import Szavak from './components/Szavak';

function App() {
  return (
    <Szavak />
  );
}

export default App;
