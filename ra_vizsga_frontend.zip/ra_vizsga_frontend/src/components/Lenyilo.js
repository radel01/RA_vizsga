import { useEffect } from "react";
import useApiContext from "../ApiContext";

export default function Lenyilo() {
    const { adat, getAdatok } = useApiContext();

    useEffect(() => {
        getAdatok('/tema');
        console.log(adat)
    }, []);
    return (
        <>
        <label htmlFor="tema" className="form-label temakLenyilo">Témák</label>
        <select className="form-select temakLenyilo" id="tema">
            <option value="" disabled>Kérem válasszon!</option>
            {adat.map((adat, index)=>(
                <option value="adat.id" key={index}>{adat.kategorianev}</option>
            ))} 
        </select>
                </>
            )
}