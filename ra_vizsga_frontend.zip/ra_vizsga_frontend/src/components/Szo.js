import { useState } from "react";

export default function Szo(props){
    const [valaszHelyes, setValaszHelyes]=useState(null);
    

   function helyesValasz(){
        const valaszHelyes=false;
        if(valaszHelyes){
            return "✔️";
        }else{
            return "X";
        }
   }
    return(
        <>
            <div className="card my-2">
                <div className="card-body">
                    <div className="angol">
                        <h4 className="fejlec">Angol</h4>
                        <h4>{props.adat.angol}</h4>
                    </div>
                    <div className="magyar">
                        <h4 className="fejlec">Magyar</h4>
                        <div className="input">
                        <input type="text" className="form-control inputSzo"  name="magyar"  />
                        </div>
                    </div>
                    <div className="visszajelzes">
                        <h4 className="fejlec">visszajelzés</h4>
                        <h4 className="visszajelzesIkon">{helyesValasz()}</h4>
                    </div>
                </div>
            </div>
        </>
    )
}