import { useEffect } from "react";
import useApiContext from "../ApiContext";
import Szo from "./Szo";
import Lenyilo from "./Lenyilo";


export default function Szavak(){
    const {adat, getAdatok}=useApiContext();

    useEffect(()=>{
        getAdatok('/szavak');
    },[]);
    return(
        <>
        <Lenyilo />
        <div className="szavak">
            {adat.map((adat, index)=>(
                    <Szo adat={adat} key={index}/>
            ))}
        </div>
        </>
    )
}